"""P8 phase 0: paired bootstrap significance for the RF-vs-GIN deltas.

Question: the campaign's effect size (3-seed mean GIN - RF) is reported per
(tag, split) cell, but is any single cell's delta separable from resampling
noise? This script resamples test MOLECULES with replacement (paired: the
same resample index matrix is applied to both models' predictions) and
turns each cell's delta into a 95% CI plus the fraction of bootstrap
deltas above zero (frac_boot_gin_better -- a fraction, NOT a p-value;
filtering it at 0.05 would drop every GIN win).
Analysis only -- no model is trained; writes go only to the output
paths listed below, each guarded against partial/mixed-size runs.

`--model gine` (P8 phase 1) reruns the identical procedure against the
GINE predictions; outputs then carry a `_gine` suffix ({tag}_{split}_gine.csv,
summary_gine.csv, ci_panel_gine.png) so the phase-0 gin artifacts are never
overwritten. Default behaviour (--model gin) is unchanged.

`--model attentivefp` (P8 phase 3) follows the same contract against the
AttentiveFP campaign's predictions: {tag}_{split}_attentivefp.csv,
summary_attentivefp.csv, ci_panel_attentivefp.png -- gin and gine
artifacts stay untouched byte-for-byte.

`--splits time` (P8 time-split analysis) gets the same protection for the
shared outputs: cell files already carry the split in their name
({tag}_time.csv), and any run touching a split outside the default
random/scaffold set auto-suffixes the shared summary/figure with that
split name -> summary_time.csv, ci_panel_time.png (see split_suffix).
The campaign's summary.csv and ci_panel.png are therefore never
overwritten by a time run.

The shared summary/figure are merge-updated by (tag, split, pair), never
blindly rewritten: rows already on disk whose n_boot differs from the
current run's are left alone unless --force is passed (refusing to mix
e.g. B=300 smoke-test rows into the B=10000 campaign table). A run that
does not cover the full tag set or uses a non-default --n-boot is a
partial run: it writes summary_partial{suffix}.csv /
ci_panel_partial{suffix}.png and never touches the campaign files, so
`--tags egfr --n-boot 300` can no longer shrink the 32-row summary to 4.
A non-default --out-dir also moves the default figure there, so a
scratch smoke run writes summary AND figure outside the repo (--fig
overrides the default).

The same protections cover the per-cell CSVs and the campaign figure:
a cell file stored with a different n_boot is never overwritten without
--force (a B=300 smoke run must not replace a B=10000 cell the panels
read), and a campaign run whose (tag, split) coverage is a strict subset
of the stored campaign summary (e.g. all 8 tags but --splits random
only) is refused unless --force, so the campaign forest can never be
silently redrawn from a subset. n_boot is recorded as the REQUESTED
bootstrap size (degenerate resamples are dropped only from the
percentiles), so an identical rerun always compares equal to the
stored rows; the shared summary rows record boot_seed alongside it,
and the summary-level n_boot guard runs in the preflight -- BEFORE any
cell CSV is rewritten, not after.

Inputs (per tag x split; test_idx alignment is asserted, never assumed):
  results/rf_preds_{tag}_{split}.npz          RF test preds (original pIC50)
  results/gnn_preds_{tag}_{split}.npz         GIN seed 42   (--model gine /
  results/gnn_preds_{tag}_{split}_seed1.npz   GIN seed 1     attentivefp:
  results/gnn_preds_{tag}_{split}_seed2.npz   GIN seed 2     infix _gine /
                                                             _attentivefp)

Two conventions ("model_pair" rows, both written for every cell):
  seed42  single seed-42 GIN vs RF            (reference; single-seed
                                               deltas are seed noise)
  mean3   per-molecule mean of the 3 GIN seed
          predictions vs RF                    (primary; matches the
                                               campaign's mean convention)

Effect-size signs (documented so the CSV cannot be misread):
  delta_r2   = R2_GIN - R2_RF    > 0 favours GIN
  delta_rmse = RMSE_GIN - RMSE_RF  > 0 favours RF (GIN worse)

Both pairs of one cell draw from an identically seeded Generator
(seed=42, fresh per call), so seed42 and mean3 are evaluated on the exact
same resample matrices and the run is order-independent.

Outputs (suffix `_gine` / `_attentivefp` on every path when --model gine /
attentivefp; gin is unchanged; the shared summary/figure additionally carry
the split suffix when --splits touches a split outside random/scaffold,
e.g. summary_time.csv / ci_panel_time.png -- see split_suffix):
  results/significance/{tag}_{split}.csv   one row per model_pair with the
                                           point deltas, the 95% CI bounds,
                                           frac_boot_gin_better =
                                           #(dR2_boot > 0)/B, and n_boot
  results/significance/summary{suffix}.csv cells x 2 pairs;
                                           significant = CI excludes 0;
                                           n_boot and boot_seed recorded per
                                           row so a merge can refuse to mix
                                           bootstrap sizes or seeds
  results/significance/summary_partial{suffix}.csv
                                           the same, for partial runs (never
                                           touches the campaign summary)
  figures/significance/ci_panel{suffix}.png forest plot, one row per
                                           (tag, split), faceted by pair
  figures/significance/ci_panel_partial{suffix}.png
                                           the same, for partial runs
Console: per-pair tally of cells whose CI excludes 0 and the list of
cells where RF (or GIN/GINE) wins significantly.
"""
import argparse
import os
import sys

import numpy as np
import pandas as pd

BASE = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, os.path.join(BASE, "scripts"))
from time_labels import load_time_split, require_prediction_version  # noqa: E402

TAGS = ("a2a", "abl1", "egfr", "egfr_full", "herg", "hivpr", "mpro", "vegfr2")
SPLITS = ("random", "scaffold")
MODELS = ("gin", "gine", "attentivefp")
SEED_SUFFIXES = ("", "_seed1", "_seed2")
PAIRS = ("seed42", "mean3")
N_BOOT = 10_000
BOOT_SEED = 42
CI_PCT = (2.5, 97.5)
CHUNK = 500          # resamples per vectorised block (bounds peak memory)

SUMMARY_COLS = ["tag", "split", "pair", "d_r2", "ci_lo", "ci_hi",
                "significant", "winner", "frac_boot_gin_better",
                "d_rmse", "d_rmse_ci_lo", "d_rmse_ci_hi", "n_boot"]
SUMMARY_KEYS = ("tag", "split", "pair")


# ---------------------------------------------------------------- naming

def gnn_preds_name(tag, split, seed_suffix, model="gin"):
    """Preds npz filename; gin keeps the campaign's infix-free names."""
    infix = "" if model == "gin" else f"_{model}"
    return f"gnn_preds_{tag}{infix}_{split}{seed_suffix}.npz"


def out_stem(tag, split, model="gin"):
    """Output stem per cell: gine artifacts carry a distinguishing suffix."""
    return f"{tag}_{split}" if model == "gin" else f"{tag}_{split}_{model}"


def summary_name(model="gin", suffix="", partial=False):
    """Shared summary filename; suffix separates split groups (e.g. _time).

    Partial runs default to the summary_partial name so a smoke test can
    never clobber the campaign table.
    """
    base = f"summary_partial{suffix}" if partial else f"summary{suffix}"
    return f"{base}.csv" if model == "gin" else f"{base}_{model}.csv"


def default_fig_name(model="gin", suffix="", partial=False):
    """Shared forest-plot filename; suffix separates split groups."""
    base = f"ci_panel_partial{suffix}" if partial else f"ci_panel{suffix}"
    return f"{base}.png" if model == "gin" else f"{base}_{model}.png"


def split_suffix(splits):
    """Suffix protecting the shared summary/figure from a foreign split.

    Cell outputs already carry the split ({tag}_{split}.csv), but
    summary.csv / ci_panel.png are shared across splits: a run touching
    any split outside the campaign's default random/scaffold set must not
    clobber them. Returns "" for default-only runs (legacy names kept
    byte-for-byte) and e.g. "_time" the moment time is requested.
    """
    extra = [s for s in splits if s not in SPLITS]
    if not extra:
        return ""
    return "_" + "_".join(extra)



# ---------------------------------------------------------------- metrics

def r2(y_true, y_pred):
    y_true = np.asarray(y_true, dtype=np.float64)
    y_pred = np.asarray(y_pred, dtype=np.float64)
    sst = float(((y_true - y_true.mean()) ** 2).sum())
    return 1.0 - float(((y_true - y_pred) ** 2).sum()) / sst


def rmse(y_true, y_pred):
    y_true = np.asarray(y_true, dtype=np.float64)
    y_pred = np.asarray(y_pred, dtype=np.float64)
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))


# ---------------------------------------------------------------- loading

def load_cell(tag, split, model="gin"):
    """Aligned (y_true, rf_pred, gnn42_pred, gnn_mean3_pred) for one cell.

    Alignment is checked against the split npz test_idx (and the GNN files
    against the RF file) -- predictions are never zipped by position alone.
    """
    def _npz(name):
        path = os.path.join(BASE, "results", name)
        if not os.path.exists(path):
            raise FileNotFoundError(f"missing {os.path.relpath(path, BASE)}")
        return np.load(path)

    rf = _npz(f"rf_preds_{tag}_{split}.npz")
    sp = np.load(os.path.join(BASE, "data", "processed", "splits",
                              f"{tag}_{split}.npz"))
    if not np.array_equal(rf["test_idx"], sp["test_idx"]):
        raise ValueError(f"{tag}/{split}: rf test_idx != split test_idx")

    if split == "time":
        marker = os.path.join(BASE, "data", "processed", "splits", f"{tag}_time_NA.json")
        if os.path.exists(marker):
            raise ValueError(f"{tag}: time split is NA; stale predictions cannot be analysed")
        if "label_policy" in sp or "label_id" in sp:
            sp = load_time_split(os.path.dirname(marker), tag)
        if "label_id" in sp or "label_id" in rf:
            require_prediction_version(rf, sp)
        else:
            print(f"[{tag}/time] historical all-year labels; not prospective validation")

    gins = []
    for suf in SEED_SUFFIXES:
        g = _npz(gnn_preds_name(tag, split, suf, model))
        if not np.array_equal(g["test_idx"], rf["test_idx"]):
            raise ValueError(f"{tag}/{split}: gnn{suffix_label(suf)} test_idx "
                             f"!= rf test_idx")
        if not np.allclose(g["y_true"], rf["y_true"], atol=1e-4):
            raise ValueError(f"{tag}/{split}: gnn{suffix_label(suf)} y_true "
                             f"!= rf y_true")
        if split == "time" and ("label_id" in sp or "label_id" in g):
            require_prediction_version(g, sp)
        gins.append(np.asarray(g["y_pred"], dtype=np.float64))

    return {
        "y": np.asarray(rf["y_true"], dtype=np.float64),
        "rf": np.asarray(rf["y_pred"], dtype=np.float64),
        "gin42": gins[0],
        "gin_mean3": np.mean(np.stack(gins), axis=0),
        "n_test": int(len(rf["test_idx"])),
        "label_id": str(sp.get("label_id", "")),
    }


def suffix_label(suf):
    return suf or " (seed42)"


# ---------------------------------------------------------------- bootstrap

def paired_bootstrap(y_true, pred_gin, pred_rf, n_boot=N_BOOT, seed=BOOT_SEED):
    """Paired bootstrap over test molecules for dR2 = R2_GIN - R2_RF.

    Vectorised: resamples are drawn in CHUNK blocks of shape (chunk, n) and
    the sums for both models are computed per block, so peak memory stays
    at a few tens of MB even for the ~2.7k-molecule cells. A fresh
    Generator(seed) per call makes the result independent of call order.
    Degenerate resamples (zero variance in y) are dropped from the
    percentiles rather than producing inf.
    """
    y = np.asarray(y_true, dtype=np.float64)
    p_gin = np.asarray(pred_gin, dtype=np.float64)
    p_rf = np.asarray(pred_rf, dtype=np.float64)
    if not (len(y) == len(p_gin) == len(p_rf)):
        raise ValueError("y_true / pred_gin / pred_rf length mismatch")
    n = len(y)
    rng = np.random.default_rng(seed)

    d_r2 = np.empty(n_boot, dtype=np.float64)
    d_rmse = np.empty(n_boot, dtype=np.float64)
    pos = 0
    while pos < n_boot:
        b = min(CHUNK, n_boot - pos)
        idx = rng.integers(0, n, size=(b, n))
        ys = y[idx]
        sst = ((ys - ys.mean(axis=1, keepdims=True)) ** 2).sum(axis=1)
        r2s, rmses = [], []
        for p in (p_gin, p_rf):
            sse = ((ys - p[idx]) ** 2).sum(axis=1)
            r2s.append(1.0 - sse / sst)
            rmses.append(np.sqrt(sse / n))
        d_r2[pos:pos + b] = r2s[0] - r2s[1]
        d_rmse[pos:pos + b] = rmses[0] - rmses[1]
        pos += b

    ok = np.isfinite(d_r2) & np.isfinite(d_rmse)
    if not ok.all():
        d_r2, d_rmse = d_r2[ok], d_rmse[ok]
        if len(d_r2) == 0:
            raise ValueError("every bootstrap resample was degenerate")
    lo, hi = np.percentile(d_r2, CI_PCT)
    rlo, rhi = np.percentile(d_rmse, CI_PCT)
    return {
        "delta_r2_point": r2(y, p_gin) - r2(y, p_rf),
        "ci_lo": float(lo),
        "ci_hi": float(hi),
        "frac_boot_gin_better": float(np.mean(d_r2 > 0)),
        "delta_rmse_point": rmse(y, p_gin) - rmse(y, p_rf),
        "delta_rmse_ci_lo": float(rlo),
        "delta_rmse_ci_hi": float(rhi),
        # the REQUESTED n_boot, not len(d_r2): degenerate resamples are
        # dropped only from the percentiles, and recording the post-filter
        # count would make an identical rerun fail the stored-rows n_boot
        # comparison in merge_summary
        "n_boot": int(n_boot),
    }


def cell_rows(tag, split, n_boot=N_BOOT, seed=BOOT_SEED, model="gin"):
    """The two model_pair rows for one (tag, split) cell."""
    cell = load_cell(tag, split, model)
    rows = []
    for pair in PAIRS:
        pred_gin = cell["gin42"] if pair == "seed42" else cell["gin_mean3"]
        res = paired_bootstrap(cell["y"], pred_gin, cell["rf"],
                               n_boot=n_boot, seed=seed)
        lo, hi = res["ci_lo"], res["ci_hi"]
        rows.append({
            "tag": tag,
            "split": split,
            **({"label_id": cell["label_id"]} if split == "time" else {}),
            "model_pair": pair,
            "n_test": cell["n_test"],
            "r2_gin": r2(cell["y"], pred_gin),
            "r2_rf": r2(cell["y"], cell["rf"]),
            "delta_r2_point": res["delta_r2_point"],
            "ci_lo": lo,
            "ci_hi": hi,
            "significant": bool(lo > 0 or hi < 0),
            "winner": model if lo > 0 else ("rf" if hi < 0 else "tie"),
            "frac_boot_gin_better": res["frac_boot_gin_better"],
            "delta_rmse_point": res["delta_rmse_point"],
            "delta_rmse_ci_lo": res["delta_rmse_ci_lo"],
            "delta_rmse_ci_hi": res["delta_rmse_ci_hi"],
            "n_boot": res["n_boot"],
            "boot_seed": seed,
        })
    return rows


# ---------------------------------------------------------------- figure

def figure_cells(rows):
    """(tag, split) cells to plot, in row order.

    Derived from the rows rather than the default TAGS x SPLITS grid so a
    --splits time run plots its own cells instead of an all-missing grid.
    """
    return [(r["tag"], r["split"]) for r in rows
            if r["model_pair"] == PAIRS[0]]


def make_figure(rows, fig_path, n_boot=N_BOOT, model="gin"):
    """Forest plot: one row per (tag, split), one panel per model_pair."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    os.makedirs(os.path.dirname(os.path.abspath(fig_path)), exist_ok=True)
    cells = figure_cells(rows)
    y_pos = np.arange(len(cells))[::-1]   # first cell at the top

    fig, axes = plt.subplots(1, 2, figsize=(11.5, 7.0), sharey=True)
    colors = {"rf": "tab:red", model: "tab:blue", "tie": "0.55"}
    label = model.upper()
    for ax, pair in zip(axes, PAIRS):
        lookup = {(r["tag"], r["split"]): r for r in rows
                  if r["model_pair"] == pair}
        for y, cell in zip(y_pos, cells):
            r = lookup.get(cell)
            if r is None:
                continue
            c = colors[r["winner"]]
            ax.errorbar(r["delta_r2_point"], y,
                        xerr=[[r["delta_r2_point"] - r["ci_lo"]],
                              [r["ci_hi"] - r["delta_r2_point"]]],
                        fmt="o", color=c, capsize=3, markersize=5.5,
                        linewidth=1.4)
        ax.axvline(0, color="black", linestyle="--", linewidth=1)
        ax.set_xlabel(f"ΔR² ({label} − RF), 95% CI")
        ax.set_title(f"pair = {pair}" + ("  (primary)" if pair == "mean3" else ""))
        ax.grid(axis="x", alpha=0.3)
        ax.set_yticks(y_pos)
        ax.set_yticklabels([f"{t}/{s}" for t, s in cells], fontsize=8)
    handles = [plt.Line2D([], [], marker="o", ls="", color=c,
                          label=lab)
               for c, lab in ((colors["rf"], "RF wins (CI < 0)"),
                              (colors[model], f"{label} wins (CI > 0)"),
                              (colors["tie"], "CI includes 0"))]
    fig.legend(handles=handles, loc="lower center", ncol=3, fontsize=8,
               frameon=False)
    fig.suptitle(f"Paired bootstrap of ΔR² ({label} − RF), B = "
                 f"{n_boot}, test molecules resampled", fontsize=11)
    fig.tight_layout(rect=(0, 0.05, 1, 0.96))
    fig.savefig(fig_path, dpi=150)
    plt.close(fig)


# ---------------------------------------------------------------- summary merge

def read_existing_summary(path):
    """An existing summary frame normalised to the current schema.

    Campaign summaries written before the n_boot column existed are
    validated as B=N_BOOT (that is the only size the campaign ever ran),
    and the retired p_one_sided column is renamed to
    frac_boot_gin_better so legacy files can still be merge-updated.
    A missing boot_seed column (files written before the column existed)
    is filled with the campaign default, matching check_cell_csv.
    """
    old = pd.read_csv(path)
    if "n_boot" not in old.columns:
        old["n_boot"] = N_BOOT
    if "boot_seed" not in old.columns:
        old["boot_seed"] = BOOT_SEED
    if "p_one_sided" in old.columns and "frac_boot_gin_better" not in old.columns:
        old = old.rename(columns={"p_one_sided": "frac_boot_gin_better"})
    return old


def merge_summary(summary, summary_path, n_boot, force=False):
    """Merge-update summary_path by (tag, split, pair); return the merged frame.

    Keys already on disk are refreshed from `summary`; untouched keys are
    kept. Rows whose stored n_boot differs from this run's are never
    silently mixed: without --force a SystemExit names the conflict (and
    points a smoke run at a scratch --out-dir instead), with --force
    exactly those keys are overwritten (--force skips this guard, the
    per-cell guard and the campaign-coverage guard together). A missing
    target is written fresh. Columns `summary` carries beyond SUMMARY_COLS
    (currently boot_seed) ride along after the standard ones; kept rows
    keep their stored values (legacy rows default to BOOT_SEED).
    """
    if not os.path.exists(summary_path):
        return summary
    old = read_existing_summary(summary_path).set_index(list(SUMMARY_KEYS))
    new = summary.set_index(list(SUMMARY_KEYS))
    overlap = old.index.isin(new.index)
    stale = old[overlap & (old["n_boot"] != n_boot)]
    if len(stale) and not force:
        rel = os.path.relpath(summary_path, BASE)
        raise SystemExit(
            f"{rel}: {len(stale)} stored row(s) for these cells have a "
            f"different n_boot ({sorted(set(stale['n_boot']))} vs this "
            f"run's {n_boot}); refusing to mix bootstrap sizes. A smoke run "
            "should write to a scratch --out-dir (summary AND figure land "
            "there; --fig overrides), not into the campaign directory; "
            "--force overwrites those keys.")
    kept = old[~overlap].reset_index()
    merged = pd.concat([kept, summary], ignore_index=True)
    extra = [c for c in summary.columns if c not in SUMMARY_COLS]
    return merged[list(SUMMARY_COLS) + extra]


def is_campaign_run(tags, n_boot):
    """Full tag set at the default B -> may merge into the campaign table.

    Anything else (a tag subset, a smoke-test B) is a partial run: it
    must stay clear of the campaign summary/figure. Split coverage
    against the *stored* campaign summary is checked separately by
    guard_campaign_coverage (a full-tag --splits random run passes this
    function but must not redraw the campaign forest from 16 of 32
    cells).
    """
    return set(tags) == set(TAGS) and n_boot == N_BOOT


def check_cell_csv(path, n_boot, force=False, seed=BOOT_SEED):
    """Refuse to overwrite a stored per-cell CSV with a different guard key.

    The guard key is (n_boot, boot_seed): the panels and reviewers read
    these files per (tag, split), so a B=300 smoke run must not silently
    replace a B=10000 cell, and a run with a different bootstrap seed must
    not replace cells whose CIs were drawn from another seed's resamples.
    A missing n_boot / boot_seed column (files written before the column
    existed) validates as the campaign defaults (N_BOOT / BOOT_SEED),
    matching read_existing_summary. With --force the overwrite proceeds
    and is announced -- but --force skips ALL THREE campaign guards at
    once (this per-cell guard, merge_summary's n_boot guard and
    guard_campaign_coverage), so a smoke run should never need it: point
    --out-dir at a scratch directory instead (partial runs already land on
    the summary_partial / ci_panel_partial names, leaving the campaign
    files untouched).
    """
    if not os.path.exists(path):
        return
    old = pd.read_csv(path)
    if "n_boot" not in old.columns:
        old["n_boot"] = N_BOOT
    if "boot_seed" not in old.columns:
        old["boot_seed"] = BOOT_SEED
    stored = sorted({int(v) for v in old["n_boot"]})
    stored_seeds = sorted({int(v) for v in old["boot_seed"]})
    if all(v == n_boot for v in stored) and all(v == seed for v in stored_seeds):
        return
    rel = os.path.relpath(path, BASE)
    if not force:
        raise SystemExit(
            f"{rel}: stored (n_boot, boot_seed)={list(zip(stored, stored_seeds))} "
            f"!= this run's ({n_boot}, {seed}); refusing to overwrite the "
            "per-cell CSV. A smoke run belongs in a scratch --out-dir "
            "(summary AND figure land there; --fig overrides), not over "
            "the campaign cells; --force skips this guard and the other "
            "two campaign guards together.")
    print(f"  [force] overwriting {rel} (stored n_boot {stored} / "
          f"boot_seed {stored_seeds} -> {n_boot} / {seed})")


def guard_campaign_coverage(summary_path, tags, splits, force=False):
    """Refuse campaign outputs from a strict subset of the stored cells.

    A full-tag run over only part of the campaign's splits (e.g.
    --splits random) merge-updates the campaign summary without losing
    rows, but the figure is drawn from this run's rows only: without
    this guard the campaign forest would silently drop every stored cell
    the run did not rerun. The stored summary defines the expected cell
    set; covering a strict subset requires an explicit --force -- which
    skips all three campaign guards at once (this coverage guard,
    merge_summary's n_boot guard and check_cell_csv's per-cell guard), so
    a smoke or subset run should write to a scratch --out-dir (the
    partial summary/figure path) instead of forcing its way into the
    campaign files.
    """
    if not os.path.exists(summary_path):
        return
    old = read_existing_summary(summary_path)
    stored = set(zip(old["tag"], old["split"]))
    run = {(t, s) for t in tags for s in splits}
    missing = sorted(stored - run)
    if not missing:
        return
    rel = os.path.relpath(summary_path, BASE)
    if not force:
        cells = ", ".join(f"{t}/{s}" for t, s in missing)
        raise SystemExit(
            f"{rel}: this run covers {len(run)} of the {len(stored)} "
            f"stored campaign cells; missing {cells}. Redrawing the "
            "campaign summary/figure from a subset needs an explicit "
            "--force (which skips every campaign guard); a smoke run "
            "should use a scratch --out-dir instead.")
    print(f"  [force] campaign coverage is a subset ({len(missing)} "
          "stored cell(s) not rerun; their summary rows are kept, the "
          "figure is drawn from this run's cells only)")


def guard_summary_n_boot(summary_path, tags, splits, n_boot, force=False):
    """Refuse summary rows for the run's cells stored at a different n_boot.

    Same conflict merge_summary refuses, but checked BEFORE the write
    loop: the old placement let a smoke run rewrite every cell CSV and
    only then abort when the summary merge hit the mixed-B rows. Here the
    stored summary defines the conflict set and the run only supplies the
    cells (tag, split) it would refresh; --force skips this guard and the
    other two campaign guards together, so a smoke run should write to a
    scratch --out-dir (summary AND figure land there; --fig overrides)
    instead of forcing its way into the campaign files.
    """
    if not os.path.exists(summary_path):
        return
    old = read_existing_summary(summary_path)
    run = {(t, s) for t in tags for s in splits}
    overlap = pd.Series([(t, s) in run
                         for t, s in zip(old["tag"], old["split"])],
                        index=old.index)
    stale = old[overlap & (old["n_boot"] != n_boot)]
    if len(stale) and not force:
        rel = os.path.relpath(summary_path, BASE)
        raise SystemExit(
            f"{rel}: {len(stale)} stored row(s) for these cells have a "
            f"different n_boot ({sorted(set(stale['n_boot']))} vs this "
            f"run's {n_boot}); refusing to mix bootstrap sizes. A smoke run "
            "should write to a scratch --out-dir (summary AND figure land "
            "there; --fig overrides), not into the campaign directory; "
            "--force overwrites those keys.")


# ---------------------------------------------------------------- report

def print_conclusion(summary, model="gin"):
    """Console verdict: which cells' CIs exclude 0, per convention."""
    label = model.upper()
    print(f"\n=== Paired bootstrap significance: {label} vs RF ===")
    print(f"  dR2 = R2_{label} - R2_RF (positive favours {label}); "
          "significant = 95% CI excludes 0")
    for pair in PAIRS:
        sub = summary[summary["pair"] == pair]
        sig = sub[sub["significant"]]
        rf_wins = [f"{r.tag}/{r.split}" for r in sig.itertuples()
                   if r.winner == "rf"]
        gin_wins = [f"{r.tag}/{r.split}" for r in sig.itertuples()
                    if r.winner == model]
        print(f"\n  [{pair}] {len(sig)}/{len(sub)} cells with CI excluding 0")
        if rf_wins:
            print(f"    RF significantly ahead ({len(rf_wins)}): "
                  f"{', '.join(rf_wins)}")
        if gin_wins:
            print(f"    {label} significantly ahead ({len(gin_wins)}): "
                  f"{', '.join(gin_wins)}")
        if not rf_wins and not gin_wins:
            print("    no cell separates from zero")
        d = sub["d_r2"]
        print(f"    dR2 point range: [{d.min():+.4f}, {d.max():+.4f}]")
    m3 = summary[summary["pair"] == "mean3"]
    n = len(m3)
    n_rf = int(((m3["ci_hi"] < 0)).sum())
    print(f"\n  mean3 (primary): RF significantly wins in {n_rf}/{n} cells; "
          f"{label} in {int((m3['ci_lo'] > 0).sum())}/{n}; "
          f"{int((~m3['significant']).sum())}/{n} inconclusive")


# ---------------------------------------------------------------- main

def parse_args(argv=None):
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("--model", default="gin", choices=list(MODELS),
                   help="GNN variant to compare against RF (default gin; "
                        "gine/attentivefp write *_gine / *_attentivefp "
                        "outputs)")
    p.add_argument("--tags", default=",".join(TAGS),
                   help="comma-separated dataset tags")
    p.add_argument("--splits", default=",".join(SPLITS),
                   help="comma-separated splits (random, scaffold, time); "
                        "non-default splits suffix the shared summary/fig "
                        "(e.g. summary_time.csv)")
    p.add_argument("--n-boot", type=int, default=N_BOOT)
    p.add_argument("--seed", type=int, default=BOOT_SEED,
                   help="bootstrap Generator seed (fixed for reproducibility)")
    p.add_argument("--force", action="store_true",
                   help="skip ALL THREE campaign guards at once: the "
                        "per-cell (n_boot, boot_seed) overwrite check, the "
                        "summary-row n_boot merge check, and the "
                        "campaign-coverage subset check (default: each "
                        "refuses). A smoke run should NOT use --force: "
                        "point --out-dir at a scratch directory instead "
                        "(partial runs write summary_partial*/"
                        "ci_panel_partial* and never touch the campaign "
                        "files; the default figure follows a scratch "
                        "--out-dir, or pass --fig)")
    p.add_argument("--out-dir", default=os.path.join(BASE, "results",
                                                     "significance"))
    p.add_argument("--fig", default=None,
                   help="forest-plot path (default figures/significance/"
                        "{ci_panel|ci_panel_gine}.png per --model)")
    return p.parse_args(argv)


def main(args=None):
    args = parse_args(args)
    model = args.model
    tags = [t.strip() for t in args.tags.split(",") if t.strip()]
    splits = [s.strip() for s in args.splits.split(",") if s.strip()]
    if args.seed < 0:
        raise SystemExit(
            f"--seed must be a non-negative integer (got {args.seed}); "
            "np.random.default_rng rejects negative seeds")
    out_dir = os.path.abspath(args.out_dir)
    os.makedirs(out_dir, exist_ok=True)

    # Resolve the shared outputs up front so an unsafe run (campaign
    # coverage subset, mixed n_boot / boot_seed) is refused BEFORE any cell
    # CSV is touched, not after the bootstrap has already overwritten files.
    suffix = split_suffix(splits)
    partial = not is_campaign_run(tags, args.n_boot)
    summary_path = os.path.join(out_dir, summary_name(model, suffix,
                                                      partial=partial))
    if not partial:
        guard_campaign_coverage(summary_path, tags, splits,
                                force=args.force)
    # the summary-level n_boot conflict is refused up front too: merge
    # runs after the write loop, so a late SystemExit there would leave
    # every cell CSV already rewritten (Low, PR #6)
    guard_summary_n_boot(summary_path, tags, splits, args.n_boot,
                         force=args.force)

    # Full preflight of EVERY cell before the write loop: the old in-loop
    # check aborted on a later mismatch only after earlier cells had been
    # rewritten. Any mismatch here SystemExits before a single file is
    # written.
    cell_paths = {}
    for tag in tags:
        for split in splits:
            path = os.path.join(out_dir, f"{out_stem(tag, split, model)}.csv")
            cell_paths[(tag, split)] = path
            check_cell_csv(path, args.n_boot, force=args.force,
                           seed=args.seed)

    rows = []
    for tag in tags:
        for split in splits:
            path = cell_paths[(tag, split)]
            cell = cell_rows(tag, split, n_boot=args.n_boot, seed=args.seed,
                             model=model)
            pd.DataFrame(cell).to_csv(path, index=False)
            for r in cell:
                rows.append(r)
            print(f"[{tag}/{split}] n={cell[0]['n_test']}  "
                  f"mean3 dR2={cell[1]['delta_r2_point']:+.4f} "
                  f"CI[{cell[1]['ci_lo']:+.4f}, {cell[1]['ci_hi']:+.4f}]  "
                  f"frac_boot_gin_better={cell[1]['frac_boot_gin_better']:.4f}")
    if not rows:
        print("no cells processed")
        return

    summary_rows = [{**r,
                     "pair": r["model_pair"],
                     "d_r2": r["delta_r2_point"],
                     "d_rmse": r["delta_rmse_point"],
                     "d_rmse_ci_lo": r["delta_rmse_ci_lo"],
                     "d_rmse_ci_hi": r["delta_rmse_ci_hi"],
                     "n_boot": r["n_boot"],
                     "boot_seed": r["boot_seed"]}
                    for r in rows]
    # boot_seed rides along after the standard columns so a summary row
    # records the resamples its CIs were drawn from (SUMMARY_COLS itself
    # stays the stable merge schema; legacy rows default to BOOT_SEED)
    summary = pd.DataFrame(summary_rows,
                           columns=SUMMARY_COLS + ["boot_seed"]
                           + (["label_id"] if "time" in splits else []))
    merged = merge_summary(summary, summary_path, n_boot=args.n_boot,
                           force=args.force)
    merged.to_csv(summary_path, index=False)

    default_out = os.path.abspath(os.path.join(BASE, "results",
                                               "significance"))
    if args.fig:
        fig_path = os.path.abspath(args.fig)
    elif out_dir != default_out:
        # a scratch --out-dir run must not write its figure into the
        # repo's figures/significance: the figure follows the out-dir
        # (--fig overrides)
        fig_path = os.path.join(out_dir, default_fig_name(model, suffix,
                                                          partial=partial))
    else:
        fig_path = os.path.join(BASE, "figures", "significance",
                                default_fig_name(model, suffix,
                                                 partial=partial))
    fig_path = os.path.abspath(fig_path)
    make_figure(rows, fig_path, n_boot=args.n_boot, model=model)
    print_conclusion(summary, model=model)
    if suffix:
        print(f"\nsplit suffix '{suffix}': shared outputs kept separate "
              "from the random/scaffold campaign files")
    if partial:
        print(f"\npartial run ({len(tags)} tag(s), n_boot={args.n_boot}): "
              "campaign summary/figure left untouched -- only a full-tag "
              "run at the default --n-boot merges into them")
    print(f"\nsummary -> {os.path.relpath(summary_path, BASE)} "
          f"({len(merged)} rows)")
    print(f"figure  -> {os.path.relpath(fig_path, BASE)}")


if __name__ == "__main__":
    main()
